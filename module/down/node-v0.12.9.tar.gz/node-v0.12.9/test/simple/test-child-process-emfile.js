// Copyright Joyent, Inc. and other Node contributors.
//
// Permission is hereby granted, free of charge, to any person obtaining a
// copy of this software and associated documentation files (the
// "Software"), to deal in the Software without restriction, including
// without limitation the rights to use, copy, modify, merge, publish,
// distribute, sublicense, and/or sell copies of the Software, and to permit
// persons to whom the Software is furnished to do so, subject to the
// following conditions:
//
// The above copyright notice and this permission notice shall be included
// in all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
// OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
// MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN
// NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
// DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
// OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE
// USE OR OTHER DEALINGS IN THE SOFTWARE.

var common = require('../common');
var assert = require('assert');
var spawn = require('child_process').spawn;
var fs = require('fs');

if (process.platform === 'win32') {
  console.log('Skipping test, no RLIMIT_NOFILE on Windows.');
  return;
}

for (;;) {
  try {
    fs.openSync(__filename, 'r');
  } catch (err) {
    assert(err.code === 'EMFILE' || err.code === 'ENFILE');
    break;
  }
}

// Should emit an error, not throw.
var proc = spawn(process.execPath, ['-e', '0']);

proc.on('error', common.mustCall(function(err) {
  assert(err.code === 'EMFILE' || err.code === 'ENFILE');
}));

// 'exit' should not be emitted, the process was never spawned.
proc.on('exit', assert.fail);
