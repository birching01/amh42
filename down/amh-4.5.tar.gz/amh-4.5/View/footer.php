<?php !defined('_Amysql') && exit; ?>

<div id="footer">
AMH mod V45 [LNMP] Powered by <a href="http://amysql.com/" target="_blank">amysql.com</a>  &nbsp;Modified by <a href="https://www.sxsay.com/" target="_blank">sxsay.com</a> <br />
©2013 专注于LNMP / Nginx 平台架构开发
</div>
</body>
</html>