#ifndef PHP_DB1_H
#define PHP_DB1_H

#if DBA_DB1

#include "php_dba.h"

DBA_FUNCS(db1);

#endif

#endif
