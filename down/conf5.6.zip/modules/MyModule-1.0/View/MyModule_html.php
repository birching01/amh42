<?php include('header.php'); ?>	<!-- 载入面板头部文件 -->
<div id="body">
	<h2>AMH » MyModule</h2>
	<h1>Hello <?php echo $name;?>！</h1>  <!-- 输出$name变量值 -->
</div>
<?php include('footer.php'); ?>	<!-- 载入面板底部文件 -->
